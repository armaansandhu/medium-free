package com.armaan.summarizer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    void linkPage(View view){
        Intent intent = new Intent(this,ThroughLink.class);
        startActivity(intent);
    }

    void textPage(View view){
        Intent intent = new Intent(this,ThroughText.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void favourites(View view) {
        Intent intent = new Intent(this,FavouriteSummaries.class);
        startActivity(intent);
    }
}
