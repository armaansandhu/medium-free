package com.armaan.summarizer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ThroughText extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_through_text);
    }
}
