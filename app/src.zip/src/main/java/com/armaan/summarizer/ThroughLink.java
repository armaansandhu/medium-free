    package com.armaan.summarizer;

    import android.content.Intent;
    import android.os.AsyncTask;
    import android.support.v7.app.AppCompatActivity;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.EditText;
    import android.widget.ProgressBar;

    import org.jsoup.Jsoup;
    import org.jsoup.nodes.Document;

    import java.io.IOException;
    import java.io.Serializable;

    import com.armaan.summarizer.Model.Summary;
    import com.armaan.summarizer.Summarizer.SummaryTool;

    public class ThroughLink extends AppCompatActivity {

        EditText urlInput;
        ProgressBar loadingSummary;

        void linkSummarize(View view){
            loadingSummary.setVisibility(View.VISIBLE);
            String url = formUrl(urlInput.getText().toString());
            new UrlParser().execute(url);
        }

        String formUrl(String oldUrl){
            if(oldUrl.contains("http://") || oldUrl.contains("https://")){
                return oldUrl;
            }
            else{
                oldUrl = "http://" + oldUrl;
                return oldUrl;
            }
        }

        public class UrlParser extends AsyncTask<String,Void,Summary>{
            String text;
            String title;
            String url;
            @Override
            protected Summary doInBackground(String... strings) {
                try {
                    Document doc = Jsoup.connect(strings[0]).get();
                    SummaryTool summaryTool = new SummaryTool();
                    summaryTool.init(doc.text());
                    summaryTool.extractSentenceFromContext();
                    summaryTool.groupSentencesIntoParagraphs();
                    summaryTool.createIntersectionMatrix();
                    summaryTool.createDictionary();
                    summaryTool.createSummary();
                    text = summaryTool.getSummary();
                    title = doc.title();
                    url = strings[0];
                    return new Summary(title,text,url);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Summary s) {
                super.onPostExecute(s);
                loadingSummary.setVisibility(View.GONE);
                Intent intent = new Intent(getBaseContext(),SummaryActivity.class);
                try {
                    String st = ObjectSerializer.serialize(s);
                    intent.putExtra("summaryText",st);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                startActivity(intent);
            }
        }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            setTitle(R.string.link_activity);
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_through_link);
            urlInput = (EditText) findViewById(R.id.urlInput);
            loadingSummary = (ProgressBar) findViewById(R.id.loadingSummary);
            loadingSummary.setVisibility(View.GONE);

        }
    }
