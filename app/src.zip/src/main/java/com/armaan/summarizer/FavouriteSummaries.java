package com.armaan.summarizer;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.armaan.summarizer.Model.Summary;

import java.io.IOException;
import java.util.ArrayList;

public class FavouriteSummaries extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite_summaries);

        ListView listView = (ListView) findViewById(R.id.list);
        ArrayList<Summary> summaries = new ArrayList<Summary>();
        ArrayList<String> titles = new ArrayList<String>();
        SharedPreferences sharedPreferences = this.getSharedPreferences("com.armaan.summarizer",MODE_PRIVATE);
        try {
            summaries = (ArrayList<Summary>) ObjectSerializer.deserialize(sharedPreferences.getString("summaries","kk"));
            for(Summary summary: summaries)
                titles.add(summary.getTitle());
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,titles);
        listView.setAdapter(adapter);
    }
}
